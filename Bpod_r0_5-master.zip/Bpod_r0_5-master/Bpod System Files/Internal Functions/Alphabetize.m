function SortedList = Alphabetize(List)

% Alphabetizes a cell array of strings

