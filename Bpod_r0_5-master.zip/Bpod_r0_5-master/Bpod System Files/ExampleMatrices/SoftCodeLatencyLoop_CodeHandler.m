function SoftCodeLatencyLoop_CodeHandler(SoftCode)
if SoftCode == 1
    SendBpodSoftCode(0);
end