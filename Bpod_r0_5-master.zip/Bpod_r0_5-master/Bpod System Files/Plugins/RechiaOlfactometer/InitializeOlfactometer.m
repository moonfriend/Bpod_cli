OlfactometerLink = TCPClient('create', '192.168.1.110', 3336);    
ok = TCPClient('connect', OlfactometerLink);